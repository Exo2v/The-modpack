tellraw @s ""
tellraw @s ["",{"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}]
tellraw @s ["",{"text":"🧭 ","color":"gold"},{"text":"ASHENFALL WAYFINDER MENU","color":"gold","bold":true},{"text":" — Choose a destination:","color":"yellow"}]
tellraw @s ["",{"text":"Click any option below to instantly teleport and inspect biomes:","color":"gray","italic":true}]
tellraw @s ""
tellraw @s ["",{"text":" [1] ","color":"yellow","bold":true},{"text":"The Forgotten Coast ","color":"green","bold":true},{"text":"(Spawn) ","color":"dark_gray"},{"text":"➡ [CLICK TO TELEPORT]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/function ashenfall:tp_coast"}},{"text":"\n     └─ Plains, Meadow, Forest | (0, 68, 2500)","color":"gray"}]
tellraw @s ["",{"text":" [2] ","color":"yellow","bold":true},{"text":"The Cogwork March ","color":"gold","bold":true},{"text":"(West) ","color":"dark_gray"},{"text":"➡ [CLICK TO TELEPORT]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/function ashenfall:tp_cogwork"}},{"text":"\n     └─ Windswept Hills, River Canyons, Badlands | (-2000, 85, 0)","color":"gray"}]
tellraw @s ["",{"text":" [3] ","color":"yellow","bold":true},{"text":"The Ashen Caldera ","color":"dark_red","bold":true},{"text":"(Center) ","color":"dark_gray"},{"text":"➡ [CLICK TO TELEPORT]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/function ashenfall:tp_caldera"}},{"text":"\n     └─ Basalt Deltas, Blackstone, Crater | (0, 80, 0)","color":"gray"}]
tellraw @s ["",{"text":" [4] ","color":"yellow","bold":true},{"text":"The Solitary Glacial Spine ","color":"aqua","bold":true},{"text":"(North) ","color":"dark_gray"},{"text":"➡ [CLICK TO TELEPORT]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/function ashenfall:tp_glacial"}},{"text":"\n     └─ Frozen Peaks, Snowy Slopes, Cirques | (0, 160, -2500)","color":"gray"}]
tellraw @s ["",{"text":" [5] ","color":"yellow","bold":true},{"text":"The Gilded Dunes ","color":"yellow","bold":true},{"text":"(East) ","color":"dark_gray"},{"text":"➡ [CLICK TO TELEPORT]","color":"aqua","bold":true,"clickEvent":{"action":"run_command","value":"/function ashenfall:tp_gilded"}},{"text":"\n     └─ Desert, Badlands, Terracotta Mesas | (2500, 75, 0)","color":"gray"}]
tellraw @s ""
tellraw @s ["",{"text":"━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━","color":"dark_gray"}]
tellraw @s ""
