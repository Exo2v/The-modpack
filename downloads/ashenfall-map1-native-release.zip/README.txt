================================================================================
     ⚔ ASHENFALL — Handcrafted World Map 1 & Native Worldgen (NeoForge 1.21.1) ⚔
================================================================================

Welcome to the clean release of Ashenfall Map 1: The Handcrafted Continent of Vantyra!
This release restores pure native Lithosphere spline generation and Still Life
dense biome fullness (trees, shrubs, wildflowers, fallen logs, mossy boulders)
with zero synthetic voxel corruption, zero stepped terraces, and zero dry-land
shipwrecks.

--------------------------------------------------------------------------------
⚡ 1-CLICK QUICK START
--------------------------------------------------------------------------------
OPTION A (Automatic Installer — Recommended):
  1. Double-click "build_world.bat" (or "install_world.bat").
     - It automatically locates your Minecraft saves directory (Vanilla or TLauncher).
     - It cleans any old corrupted chunk files.
     - It sets up the clean "Ashenfall - The Broken Realm" world save in < 1 second.
  2. If you need the required mods (Lithosphere, Still Life, Create, Performance, etc.):
     - Double-click "download_mods.bat" to download all verified NeoForge 1.21.1 mods.
  3. Open Minecraft 1.21.1 NeoForge -> Singleplayer -> "Ashenfall - The Broken Realm"!

OPTION B (Manual Drag & Drop):
  1. Copy the folder "saves/Ashenfall" directly into your ".minecraft/saves" folder.
  2. Copy "kubejs" and "config" into your ".minecraft" folder.
  3. Launch Minecraft!

--------------------------------------------------------------------------------
🗺️ CONTINENT COORDINATES & FACTION ZONES (8,000 x 8,000 World Border)
--------------------------------------------------------------------------------
- Spawn Point:             X: 0, Y: 68, Z: 2500  (The Forgotten Coast - Cold Bluffs)
- The Caldera (Center):    X: 0, Z: 0            (Melted Obsidian Throne & Sunken Crater)
- The Cogwork March:       X: -2000, Z: 0        (Steampunk River Canals, Canyons & Clunkers)
- The Solitary Glacial:    X: 0, Z: -2500        (Glacial Peaks & Snowy Cirques, Y = 140-210)
- The Sunken Reach:        X: -2500, Z: 1500     (Drowned Lagoon, Tidal Flats & Reefs)
- The Gilded Dunes:        X: 2500, Z: 0         (Desert Sand Sea & Red Terracotta)
- The Whispering Fen:      X: 2000, Z: 2000      (Dense Mangrove Bayou & Muddy Deltas)
- The Veil of Salt:        Center: (0,0), Radius: 4,000 blocks (8,000 x 8,000 border)

--------------------------------------------------------------------------------
⚔️ GAMEPLAY RULES & FEATURES
--------------------------------------------------------------------------------
- Health: 20 Hearts base (40 Max HP) across all logins & respawns.
- Combat: 100% Pure Vanilla PvP (cooldown, sweep, crits, sprint hits).
- Dragons: Rare apex endgame encounters with 2,500-block sanctuary at spawn.
- Reference Maps: Open "ASHENFALL_LITHOSPHERE_MAP.png" to see the visual continent!
================================================================================
